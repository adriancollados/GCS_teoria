import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-pause',
  templateUrl: './training-pause.page.html',
  styleUrls: ['./training-pause.page.scss'],
})
export class TrainingPausePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
