import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-weeks',
  templateUrl: './training-weeks.page.html',
  styleUrls: ['./training-weeks.page.scss'],
})
export class TrainingWeeksPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
