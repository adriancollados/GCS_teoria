import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-exercise',
  templateUrl: './training-exercise.page.html',
  styleUrls: ['./training-exercise.page.scss'],
})
export class TrainingExercisePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
