import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-fitness',
  templateUrl: './training-fitness.page.html',
  styleUrls: ['./training-fitness.page.scss'],
})
export class TrainingFitnessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
