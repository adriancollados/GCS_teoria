import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-cardio',
  templateUrl: './training-cardio.page.html',
  styleUrls: ['./training-cardio.page.scss'],
})
export class TrainingCardioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
