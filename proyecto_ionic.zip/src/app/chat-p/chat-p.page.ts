import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-chat-p',
  templateUrl: './chat-p.page.html',
  styleUrls: ['./chat-p.page.scss'],
})
export class ChatPPage implements OnInit {

  constructor() { }
 
  ngOnInit() {
  }

}
