import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-page',
  templateUrl: './training-page.page.html',
  styleUrls: ['./training-page.page.scss'],
})
export class TrainingPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
