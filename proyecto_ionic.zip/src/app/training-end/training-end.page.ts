import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-end',
  templateUrl: './training-end.page.html',
  styleUrls: ['./training-end.page.scss'],
})
export class TrainingEndPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
