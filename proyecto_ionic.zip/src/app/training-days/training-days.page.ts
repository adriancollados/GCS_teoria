import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-days',
  templateUrl: './training-days.page.html',
  styleUrls: ['./training-days.page.scss'],
})
export class TrainingDaysPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
